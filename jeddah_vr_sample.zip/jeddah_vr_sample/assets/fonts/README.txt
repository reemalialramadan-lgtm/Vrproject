Place a high-quality Arabic .ttf font here (e.g., NotoNaskhArabic-Regular.ttf or Cairo.ttf).
The project uses DynamicFont to load fonts at runtime. Make sure the font supports Arabic shaping and ligatures.
