Jeddah Tower VR — Prototype (Godot 4)

This is a minimal sample project scaffold for a VR architectural visualization prototype focused on the Jeddah Tower. It contains placeholder scenes, scripts, Arabic localization stubs, and a small README to get started.

How to open:
- Download or clone the folder into your local machine.
- Open in Godot 4.2+ (export templates required to export builds).

Structure:
- scenes/
  - Plaza.tscn (main scene — exterior plaza with a tower placeholder)
  - TowerExterior.tscn
  - TowerInterior.tscn
- scripts/
  - player.gd (simple VR-friendly locomotion controls)
  - enter_tower.gd (scene change helper)
  - locale.gd (locale loader + sample calls)
- translations/ (placeholder .po files for en & ar)
- assets/fonts/ (sample Arabic font provided)
- assets/audio/ar/ (placeholder narration files)

Next steps:
- Replace placeholders with your 3D models (glTF), textures, and localized audio.
- Configure OpenXR and export for your headset.
