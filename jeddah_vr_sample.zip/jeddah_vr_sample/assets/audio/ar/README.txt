Place localized Arabic audio narration files here (OGG recommended).
Example: welcome_intro.ogg
